/********************************************************
*  File descripton
*  This code test and controls the LCD I2C slave device
*  It detects that a key has been pressed on a keypad
*  and displays the value of this key on the LCD display
*********************************************************/

#include <hidef.h>      /* common defines and macros */
#include <stdio.h>
#include "derivative.h"      /* derivative-specific definitions */
#include "i2c_utils.h"
#include "initMICRO.h"

// VARIALES                          
char strg1[]= "Testing LCD/Keypad";
char strg2[]= "Press a key: " ;
char strg3[]= "Key pressed was: ";
char strg[80];                      // Reserve space for 80 characters
unsigned char *key;                 // Pointer to space to hold reading of keyboard
char keypad[] = "123456789*0#";     // String of characters found on keypad.


// Other declarations as required


/*** MAIN SOURCE CODE ***/

void main(void) 
{

// Part 1 - Setting HCS12 and I2C device

/**** ENTER CODE HERE TO MEET REQUIREMENTS 1 and 2  ****/


// Part 2 - Test and use LCD/Keypad

/**** ENTER CODE HERE TO MEET OTHER REQUIREMENTS  ****/

         
 for (;;) {asm("NOP");}    // Just in case, stay here

}
